﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

//import module from "jquery";



//const { param } = require("jquery");
// Write your JavaScript code.

$(function () {


    var placeholderElement = $('#modal-placeholder');
    $('button[data-toggle="ajax-modal"]').click(function (event) {
        var url = $(this).data('url');
        $.get(url).done(function (data) {
            // handler in url
            placeholderElement.html(data);
            //with new modal
            placeholderElement.find('.modal').modal('show')
        });
    });

    // partial add page var
    placeholderElement.on('click', '[data-save="modal"]', function (event) {
        debugger;
        // save click event action
        event.preventDefault();
        // To go form data and send it 
        var form = $(this).parents('.modal').find('form');
        var actionurl = form.attr('action');
        var dataToSend = form.serialize();

        $.post(actionurl, dataToSend).done(function (data) {
            debugger;
            //data rendered 
            var newbody = $('.modal-body', data);
            //replace modal content with new form
            placeholderElement.find('.modal-body').replaceWith(newbody);

            var isvalid = newbody.find('[name="IsValid"]').val() == "True";
            if (isvalid) {
                debugger;
                placeholderElement.find('.modal').modal('hide');
                alert("saved");
            }

        });
    });
});
/////////////////////////////////////////////
$(function () {
    var placeholderElement1 = $('#modal-placeholder');

    $('button[data-toggle="ajax-modal1"]').click(function (event) {
        debugger;
        var url = $(this).data('url');
        $.get(url).done(function (data) {
            /*element.setAttribute('Name');*/
            placeholderElement1.html(data);
            placeholderElement1.find('.modal').modal('show')
        });

        placeholderElement1.on('click', '[data-save="modal1"]', function (event) {
            debugger;
            // save click event action
            event.preventDefault();
            // To go from data and send it 
            var form = $(this).parents('.modal').find('form');
            var actionurl = form.attr('action');
            var dataToSend = form.serialize();

            $.post(actionurl, dataToSend).done(function (data) {
                debugger;
                //data rendered
                var newbody = $('.modal-body', data);
                //replace modal content with new form
                placeholderElement1.find('.modal-body').replaceWith(newbody);

                //var isvalid = newbody.find('[name="IsValid"]').val() == "True";
                //if (isvalid) {
                debugger;
                placeholderElement1.find('.modal').modal('hide');
                alert("Updated");
                //}

            });
        });
    });

});



$(function () {
    var placeDelete = $('#modal-placeholder');
    $('button[data-toggle="ajax-delete"]').click(function (event) {
        debugger;
        var urld = $(this).data('url');
        $.get(urld).done(function (data) {
            placeDelete.html(data);
            placeDelete.find('.modal').modal('show')
        });

        placeDelete.on('click', '[data-save="modal3"]', function (event) {
            event.preventDefault();
            var form = $(this).parents('.modal').find('form');
            var actionurl = form.attr('action');
            var dataToSend = form.serialize();
            var rel = $(this).data('url');

            $.post(actionurl, dataToSend).done(function (data) {

                var newbody = $('.modal-body', data);
                //replace modal content with new form
                placeDelete.find('.modal-body').replaceWith(newbody);

                //var isvalid = newbody.find('[name="IsValid"]').val() == "True";
                //if (isvalid) {
                debugger;
                placeDelete.find('.modal').modal('hide');
                /*$('.alert').alert()*/
                alert('Deleted');
                window.location.reload();
                //var placeholderElement = $('#modal-placeholder');
                //    var url = $(this).data('url');
                //    $.get(url).done(function (data) {
                //        placeholderElement.html(data);
                //        placeholderElement.find('.table').modal('show')
                        
                //    });
                           
            });



        });

    });
});





//var placeholderElement = $('#modal-placeholder');
//debugger
//$('button[data-toggle="ajax-modal1"]').click(function (event) {
//    debugger;
//    var id = $(this).attr('formaction');
//    $.get(id).done(function (data) {
//        placeholderElement.appendTo(data);
//    });
//});

// To go from data and send it

///////////////

//$('button[data-toggle="ajax-modal1"]').click(function (event) {
//    debugger;
//    // var form = $(this).on('.modal').find('form');
//    var actionurl = $(this).attr('data-url');
//    var dataToSend = $(this).serialize();
//    var id = $(this).attr('action');

//    $.post(actionurl, id).done(function (data) {
//       // actionurl.find(Element[1]).replaceWith(id);

//        //string
//    });
//});