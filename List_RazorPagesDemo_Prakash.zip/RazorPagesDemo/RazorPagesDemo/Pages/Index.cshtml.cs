﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using RazorPagesDemo.Data;
using RazorPagesDemo.Models.Domain;
using System.Linq;
using System.Text.RegularExpressions;

namespace RazorPagesDemo.Pages
{
    public class IndexModel : PageModel
    {
        private readonly Rezorpagesdemodbcontext dbContext;
        public IndexModel(Rezorpagesdemodbcontext dbContext)
        {
            this.dbContext = dbContext;
        }
        public List<Models.Domain.ProductList> Employees { get; set; }

        //filter
        public List<string> Locationlist { get; set; }
        public List<string> HDDList { get; set; }
       

        // Pagging
        public int PageCount { get; set; }
        public int CurrentPageIndex { get; set; }
        public string? SearchString { get; set; }
        public bool ShowPrevious ;
        public bool ShowNext;
        public int AllRec;



        public void OnGet(int currentPage, string sortOrder, string SearchString,string FLocation,string FHDD, List<string> FRAM, int minSize, int maxSize)
        {
            currentPage = currentPage == 0 ? 1 : currentPage;
            int maxRows = 50;
            ViewData["NameSort"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "name_asc";
            ViewData["FLocation"] = FLocation;
            ViewData["FHDD"] = FHDD;

            //get All list
            var Employees1 = (from Employee in this.dbContext.ProductList
                              select Employee);


            Locationlist = Employees1
                  .Select(e => e.Location)
                  .Distinct()
                  .ToList();

            //sort filter 
            switch (sortOrder)
            {
                case "name_desc":
                    //Employees = Employees.OrderByDescending(Employees => Employees.Name).ToList();
                    Employees1 = Employees1.OrderByDescending(Employees => Employees.Model);
                    break;
                case "name_asc":
                    Employees1 = Employees1.OrderBy(employees  => employees.Model);
                    break;
            }


            //range HDD #1

            //Employees1 = Employees1
            // .Where(p => IsWithinSizeRange(p.HDD, minSize, maxSize));
            
            // Filter by RAM Size #2
            if (FRAM != null && FRAM.Any())
            {
                Employees1 = Employees1.Where(p => FRAM.Contains(p.RAM.Substring(0, p.RAM.Length - 4))); 
            }
            
            //////select HDD #3
            if (!string.IsNullOrEmpty(FHDD))
            {
                Employees1 = Employees1.Where(s => s.HDD.Contains(FHDD));
            }

            //select location #4
            if (!string.IsNullOrEmpty(FLocation))
            {
                Employees1 = Employees1.Where(s => s.Location.Contains(FLocation));
            }


            //serch filter
            if (!string.IsNullOrEmpty(SearchString))
            {
                Employees1 = Employees1.Where(s => s.Model.Contains(SearchString));
            }







            Employees = Employees1
                      .Skip((currentPage - 1) * maxRows)
                      .Take(maxRows).ToList();

            double pageCount = (double)((decimal)this.dbContext.ProductList.Count() / Convert.ToDecimal(maxRows));
            PageCount = (int)Math.Ceiling(pageCount);
              

            ShowPrevious = currentPage > 1 ? true : false;
            CurrentPageIndex = currentPage;
 
            ShowNext = currentPage < PageCount ? true : false;
            AllRec = this.dbContext.ProductList.Count();

        }


    

}
}