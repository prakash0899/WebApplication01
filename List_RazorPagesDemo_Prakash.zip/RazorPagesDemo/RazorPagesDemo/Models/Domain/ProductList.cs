﻿using Microsoft.Extensions.FileProviders;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace RazorPagesDemo.Models.Domain
{

	public class ProductList
	{
        public Guid Id { get; set; }

		[MaxLength(500)]
        public string Model { get; set; }

        [MaxLength(500)]
        public string RAM { get; set; }

        [MaxLength(500)]
        public string HDD { get; set; }

        [MaxLength(500)]
        public string Location { get; set; }

        [MaxLength(500)]
        public string Price { get; set; }


    }
}
