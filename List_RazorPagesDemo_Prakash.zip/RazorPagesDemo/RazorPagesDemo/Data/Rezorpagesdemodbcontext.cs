﻿using Microsoft.EntityFrameworkCore;
using RazorPagesDemo.Models.Domain;
using System.Security.Cryptography;

namespace RazorPagesDemo.Data
{
    public class Rezorpagesdemodbcontext : DbContext
    {
        public Rezorpagesdemodbcontext(DbContextOptions options) : base(options)
        {
        }



		//public DbSet<Employee> Employees { get; set; }        
		public DbSet<ProductList> ProductList { get; set; }
	}

	
}
